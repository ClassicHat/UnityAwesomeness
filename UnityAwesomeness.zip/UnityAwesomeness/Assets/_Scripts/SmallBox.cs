﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SmallBox : MonoBehaviour {
    public GameObject smallBox = GameObject.FindGameObjectWithTag("SmallBox");
    public Vector3 smallBoxPos;


	// Use this for initialization
	void Start () {
        Instantiate(smallBox);
        smallBoxPos = smallBox.transform.position;
	}
	
	// Update is called once per frame
	void Update () {
        //smallBoxPos.x += 1;
        //smallBox.transform.position.x = smallBoxPos.x;
	}
}
