﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BigBox : MonoBehaviour {
    public float mass = 1f;
    public float velocity = 1f;
    
    // Update is called once per frame
    void Update () {
        MoveBox();
	}

    void MoveBox()
    {
        this.transform.Translate(Vector3.left);
    }
}
